-- Add 'webhook' value to lead_source enum
ALTER TYPE lead_source ADD VALUE 'webhook';