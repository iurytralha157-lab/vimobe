-- Enable realtime for leads table
ALTER PUBLICATION supabase_realtime ADD TABLE public.leads;