ALTER TABLE public.round_robin_members 
ALTER COLUMN user_id DROP NOT NULL;