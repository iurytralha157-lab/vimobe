-- Enable realtime for lead_tags table
ALTER PUBLICATION supabase_realtime ADD TABLE public.lead_tags;